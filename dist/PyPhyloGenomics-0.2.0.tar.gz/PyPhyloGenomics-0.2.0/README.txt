#PyPhyloGenomics
A package to work on Phylogenomics.

In development.

###Developers
* Carlos Peña (email: carlos.pena@utu.fi)
* Victor Solis
* Pavel Matos
* Chris Wheat
